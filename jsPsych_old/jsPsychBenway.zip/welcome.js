    var timeline = [];
    /* define welcome message trial */
    var welcome = {
        type: "html-keyboard-response",
        stimulus:  "<p><div style='font-size:40px;''><strong>Reaktionstid </strong></div></p>" +
        "<p class='gap-above'> Her skal du gennemføre tre forskellige tests af din reaktionstid. </p>"+
        "<p class='gap-above'><strong><i>Tryk på en tast for at læse instruktionen til den første.</strong></i></p>"
      };
      timeline.push(welcome);
      